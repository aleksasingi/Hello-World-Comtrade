package com.example.demo.controller;


import com.example.demo.model.Notification;
import com.example.demo.services.NotificationServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class NotificationController {
    @Autowired
    NotificationServices service;


    @RequestMapping("/indexdb")
    public String viewDBPage(Model model){
        List<Notification> listNotification = service.listAll();
        model.addAttribute("listNotification", listNotification);
        return "indexdb";
    }

    @RequestMapping("/database1")
    public String viewDB1Page(Model model){
        List<Notification> listNotification = service.listAll();
        model.addAttribute("listNotification", listNotification);
        return "indexdb1";
    }

    @RequestMapping("/new")
    public String newNotificationPage(Model model) {
        Notification notification=new Notification();
        model.addAttribute(notification);
        return "/new_notification";
    }

    @RequestMapping(value="/save")
    public String saveNotification(@ModelAttribute("notification") Notification notification) {
        service.save(notification);
        return "redirect:/";
    }

}
