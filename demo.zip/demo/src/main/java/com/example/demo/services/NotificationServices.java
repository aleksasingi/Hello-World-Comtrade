package com.example.demo.services;


import com.example.demo.model.Notification;
import com.example.demo.repository.NotifRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationServices {

    @Autowired
    private NotifRepository repo;

    public List<Notification> listAll(){
        return repo.findAll();
    }

    public void save(Notification notification){
        repo.save(notification);
    }

    public Notification get(Long id){
        return repo.findById(id).get();
    }

}
