package com.example.demo;

public enum Role {
    ADMIN, USER
}
